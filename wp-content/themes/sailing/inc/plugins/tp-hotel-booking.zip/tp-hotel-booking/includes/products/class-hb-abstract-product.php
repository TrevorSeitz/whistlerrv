<?php

if ( !defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

abstract class HB_Product_Abstract {

    function __construct( $params = null ) {
        
    }

    function amount_include_tax() {
        
    }

    function amount_exclude_tax() {
        
    }

}
