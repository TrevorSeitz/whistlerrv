<?php
/**
 * @Author: ducnvtt
 * @Date:   2016-04-14 11:21:31
 * @Last Modified by:   ducnvtt
 * @Last Modified time: 2016-04-14 14:13:41
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}