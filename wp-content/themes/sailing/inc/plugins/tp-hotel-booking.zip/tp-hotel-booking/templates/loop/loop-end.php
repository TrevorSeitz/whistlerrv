<?php
/**
 * Room Loop End
 *
 * @author 		ThimPress
 * @package 	Tp-hotel-booking/Templates
 * @version     1.1.4
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit();
}

?>
</ul>
<?php wp_reset_postdata(); ?>